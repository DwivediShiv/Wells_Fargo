import axios from "axios";
import "./App.css";
import UploadFile from "./components/Upload";
import ScatterPlot from "./components/ScatterPlot";
import { useEffect, useState } from "react";

function App() {
  const [chartData, setChartData] = useState(null);
  const [errorData, setErrorData] = useState(null);

  const fetchChartData = async () => {
    try {
      const response = await axios.get("http://localhost:8080/getFileData");

      if (response.status !== 200) {
        throw new Error("Error occured while uploading");
      }

      setChartData(response.data.data);
      setErrorData(null);
    } catch (error) {
      if (error.response) {
        setErrorData(error.response.data);
      }
    }
  };

  useEffect(() => {
    fetchChartData();
  }, []);

  const uploadHandler = async (e) => {
    try {
      let formData = new FormData();
      formData.append("file", e.target.files[0]);

      const response = await axios.post(
        "http://localhost:8080/uploadFile",
        formData
      );

      if (response.status !== 200) {
        throw new Error(response.data.message);
      }

      fetchChartData();
      setErrorData(null);
    } catch (error) {
      if (error.response) {
        setErrorData(error.response.data);
      }
    }
  };

  return (
    <div className="App">
      {errorData && <h6 style={{ color: "red" }}>{errorData.message}</h6>}

      <UploadFile
        setChartData={setChartData}
        setErrorData={setErrorData}
        uploadHandler={uploadHandler}
      />

      <ScatterPlot chartData={chartData} />
    </div>
  );
}

export default App;
