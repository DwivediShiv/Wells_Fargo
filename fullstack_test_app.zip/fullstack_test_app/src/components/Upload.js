const UploadFile = (props) => {
  const { uploadHandler } = props;

  return (
    <div>
      <input
        name="uploadFile"
        id="uploadFile"
        type="file"
        onChange={uploadHandler}
      />
    </div>
  );
};

export default UploadFile;
