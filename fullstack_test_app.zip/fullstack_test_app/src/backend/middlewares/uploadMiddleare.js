const multer = require("multer");

const csvFilter = (req, file, cb) => {
  if (file.mimetype.includes("csv")) {
    cb(null, true);
  } else {
    cb("Please upload only csv file", false);
  }
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, __baseDir + "/backend/resource/static/assets/upload/");
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  },
});

const uploadedFile = multer({ storage, fileFilter: csvFilter });
module.exports = uploadedFile;
