const express = require("express");
const router = require("./Router/router");

global.__baseDir = __dirname + "/..";

const app = express();

app.use(express.json());

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*"); // CORS access
  res.setHeader("Access-Control-Allow-Methods", "GET, POST"); // Method access
  res.setHeader("Access-Control-Allow-Headers", "Content-Type"); // application/json access
  next();
});

app.use("/", router);

app.use((err, req, res, next) => {
  const status = err.statusCode || 500;
  res.status(status).json({
    message: err,
  });
});

app.listen(8080);
