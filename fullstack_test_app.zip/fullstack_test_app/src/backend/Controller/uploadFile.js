const csvToJson = require("csvtojson");
const fs = require("fs");

exports.uploadFile = (req, res, next) => {
  try {
    if (req.file == undefined) {
      return res.status(400).send("Please uplaod a csv file");
    }

    let uploadPath =
      __baseDir + "/backend/resource/static/assets/upload/" + req.file.filename;

    let jsonPath = __baseDir + "/backend/resource/static/assets/json/data.json";

    csvToJson()
      .fromFile(uploadPath)
      .then((jsonObj) => {
        const jsonContent = JSON.stringify(jsonObj);

        fs.writeFile(jsonPath, jsonContent, "utf-8", (err) => {
          if (err) {
            next(err);
          }
        });

        res.status(200).json({
          data: jsonObj,
        });
      })
      .catch((err) => {
        next(err);
      });
  } catch (error) {
    next(error);
  }
};
