const fs = require("fs");

exports.getFileData = (req, res, next) => {
  try {
    let jsonPath = __baseDir + "/backend/resource/static/assets/json/data.json";

    fs.readFile(jsonPath, (err, jsonObj) => {
      if (err) {
        next(err);
      }
      const data = JSON.parse(jsonObj);

      res.status(200).json({
        data,
      });
    });
  } catch (error) {
    next(error);
  }
};
