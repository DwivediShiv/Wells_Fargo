const express = require("express");
const { getFileData } = require("../Controller/fileData");
const { uploadFile } = require("../Controller/uploadFile");
const uploadedFile = require("../middlewares/uploadMiddleare");

const router = express.Router();

router.get("/getFileData", getFileData);

router.post("/uploadFile", uploadedFile.single("file"), uploadFile);

module.exports = router;
