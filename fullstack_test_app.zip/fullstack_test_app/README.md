1. Backend code Path
   \fullstack_test_app\src\backend

2. cd \fullstack_test_app
   to access application directory
3. node \src\backend\server.js
   for backe end to run on server port 8080

4. npm start  
   for front end to run on server port 3000
